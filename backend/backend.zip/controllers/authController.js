const jwt = require('jsonwebtoken');
const { User } = require('../models');
const { validateFields } = require('../utils/validate');
const { success, error } = require('../utils/response');

// Generate JWT Token
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE
  });
};

// @desc    Register new user
// @route   POST /api/auth/register
// @access  Public
const register = async (req, res) => {
  try {
    const { username, email, password } = req.body;
    // Validation
    const validationError = validateFields(req.body, ['username', 'email', 'password']);
    if (validationError) {
      return error(res, validationError, 400);
    }
    // Check if user already exists
    const userExists = await User.findOne({ where: { email } });
    if (userExists) {
      return error(res, 'User already exists with this email', 400);
    }
    // Check if username is taken
    const usernameExists = await User.findOne({ where: { username } });
    if (usernameExists) {
      return error(res, 'Username is already taken', 400);
    }
    // Create user (password will be hashed automatically by the model hook)
    const user = await User.create({ username, email, password, role: 'user' });
    // Generate token
    const token = generateToken(user.id);
    return success(res, {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      token
    }, 'User registered successfully', 201);
  } catch (err) {
    return error(res, 'Server error', 500, err.message);
  }
};

// @desc    Login user
// @route   POST /api/auth/login
// @access  Public
const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    // Validation
    const validationError = validateFields(req.body, ['email', 'password']);
    if (validationError) {
      return error(res, validationError, 400);
    }
    // Find user by email
    const user = await User.findOne({ where: { email } });
    if (!user) {
      return error(res, 'Invalid credentials', 401);
    }
    // Check password
    const isPasswordValid = await user.comparePassword(password);
    if (!isPasswordValid) {
      return error(res, 'Invalid credentials', 401);
    }
    // Generate token
    const token = generateToken(user.id);
    return success(res, {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      token
    }, 'Login successful', 200);
  } catch (err) {
    return error(res, 'Server error', 500, err.message);
  }
};

// @desc    Get current logged in user
// @route   GET /api/auth/me
// @access  Private
const getMe = async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id, {
      attributes: { exclude: ['password'] }
    });
    return success(res, user, undefined, 200);
  } catch (err) {
    return error(res, 'Server error', 500, err.message);
  }
};

module.exports = {
  register,
  login,
  getMe
};