'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    // comments
    await queryInterface.addIndex('comments', ['post_id']);
    await queryInterface.addIndex('comments', ['user_id']);
    await queryInterface.addIndex('comments', ['parent_id']);
    await queryInterface.addIndex('comments', ['created_at']);

    // posts
    await queryInterface.addIndex('posts', ['project_id']);
    await queryInterface.addIndex('posts', ['author_id']);
    await queryInterface.addIndex('posts', ['status']);
    await queryInterface.addIndex('posts', ['published_at']);

    // polls
    await queryInterface.addIndex('polls', ['project_id']);
    await queryInterface.addIndex('polls', ['post_id']);
    await queryInterface.addIndex('polls', ['is_active']);
    await queryInterface.addIndex('polls', ['show_on_homepage']);
    await queryInterface.addIndex('polls', ['end_date']);

    // poll_options
    await queryInterface.addIndex('poll_options', ['poll_id']);

    // poll_votes
    await queryInterface.addIndex('poll_votes', ['poll_option_id']);
    // ensure unique (poll_id, user_id)
    await queryInterface.addIndex('poll_votes', ['poll_id', 'user_id'], { unique: true, name: 'poll_votes_poll_user_unique' });

    // releases
    await queryInterface.addIndex('releases', ['project_id']);
    await queryInterface.addIndex('releases', ['is_published']);
    await queryInterface.addIndex('releases', ['release_date']);

    // release_files
    await queryInterface.addIndex('release_files', ['release_id']);

    // changelogs
    await queryInterface.addIndex('changelogs', ['project_id']);
    await queryInterface.addIndex('changelogs', ['release_date']);

    // downloads
    await queryInterface.addIndex('downloads', ['project_id']);
    await queryInterface.addIndex('downloads', ['is_active']);
    await queryInterface.addIndex('downloads', ['created_at']);

    // post_polls
    await queryInterface.addIndex('post_polls', ['post_id']);
    await queryInterface.addIndex('post_polls', ['poll_id']);
    await queryInterface.addIndex('post_polls', ['post_id', 'poll_id'], { unique: true, name: 'unique_post_poll' });

    // post_releases
    await queryInterface.addIndex('post_releases', ['post_id']);
    await queryInterface.addIndex('post_releases', ['release_id']);
    await queryInterface.addIndex('post_releases', ['post_id', 'release_id'], { unique: true, name: 'unique_post_release' });

    // comment_votes
    await queryInterface.addIndex('comment_votes', ['user_id']);
    await queryInterface.addIndex('comment_votes', ['comment_id']);
    await queryInterface.addIndex('comment_votes', ['user_id', 'comment_id'], { unique: true, name: 'unique_user_comment_vote' });
  },

  async down(queryInterface, Sequelize) {
    // Reverse order
    await queryInterface.removeIndex('comment_votes', 'unique_user_comment_vote');
    await queryInterface.removeIndex('comment_votes', ['comment_id']);
    await queryInterface.removeIndex('comment_votes', ['user_id']);

    await queryInterface.removeIndex('post_releases', 'unique_post_release');
    await queryInterface.removeIndex('post_releases', ['release_id']);
    await queryInterface.removeIndex('post_releases', ['post_id']);

    await queryInterface.removeIndex('post_polls', 'unique_post_poll');
    await queryInterface.removeIndex('post_polls', ['poll_id']);
    await queryInterface.removeIndex('post_polls', ['post_id']);

    await queryInterface.removeIndex('downloads', ['created_at']);
    await queryInterface.removeIndex('downloads', ['is_active']);
    await queryInterface.removeIndex('downloads', ['project_id']);

    await queryInterface.removeIndex('changelogs', ['release_date']);
    await queryInterface.removeIndex('changelogs', ['project_id']);

    await queryInterface.removeIndex('release_files', ['release_id']);

    await queryInterface.removeIndex('releases', ['release_date']);
    await queryInterface.removeIndex('releases', ['is_published']);
    await queryInterface.removeIndex('releases', ['project_id']);

    await queryInterface.removeIndex('poll_votes', 'poll_votes_poll_user_unique');
    await queryInterface.removeIndex('poll_votes', ['poll_option_id']);

    await queryInterface.removeIndex('poll_options', ['poll_id']);

    await queryInterface.removeIndex('polls', ['end_date']);
    await queryInterface.removeIndex('polls', ['show_on_homepage']);
    await queryInterface.removeIndex('polls', ['is_active']);
    await queryInterface.removeIndex('polls', ['post_id']);
    await queryInterface.removeIndex('polls', ['project_id']);

    await queryInterface.removeIndex('posts', ['published_at']);
    await queryInterface.removeIndex('posts', ['status']);
    await queryInterface.removeIndex('posts', ['author_id']);
    await queryInterface.removeIndex('posts', ['project_id']);

    await queryInterface.removeIndex('comments', ['created_at']);
    await queryInterface.removeIndex('comments', ['parent_id']);
    await queryInterface.removeIndex('comments', ['user_id']);
    await queryInterface.removeIndex('comments', ['post_id']);
  }
};
