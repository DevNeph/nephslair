'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    // posts tablosu
    await queryInterface.addColumn('posts', 'deleted_at', { type: Sequelize.DATE, allowNull: true });
    await queryInterface.changeColumn('posts', 'created_at', { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') });
    await queryInterface.changeColumn('posts', 'updated_at', { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') });

    // projects
    await queryInterface.addColumn('projects', 'deleted_at', { type: Sequelize.DATE, allowNull: true });
    await queryInterface.changeColumn('projects', 'created_at', { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') });
    await queryInterface.changeColumn('projects', 'updated_at', { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') });

    // polls
    await queryInterface.addColumn('polls', 'deleted_at', { type: Sequelize.DATE, allowNull: true });
    await queryInterface.changeColumn('polls', 'created_at', { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') });

    // poll_options
    await queryInterface.addColumn('poll_options', 'deleted_at', { type: Sequelize.DATE, allowNull: true });
    await queryInterface.changeColumn('poll_options', 'created_at', { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') });

    // poll_votes
    await queryInterface.addColumn('poll_votes', 'deleted_at', { type: Sequelize.DATE, allowNull: true });
    await queryInterface.changeColumn('poll_votes', 'created_at', { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') });

    // releases
    await queryInterface.addColumn('releases', 'deleted_at', { type: Sequelize.DATE, allowNull: true });
    await queryInterface.changeColumn('releases', 'created_at', { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') });
    await queryInterface.changeColumn('releases', 'updated_at', { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') });

    // release_files
    await queryInterface.addColumn('release_files', 'deleted_at', { type: Sequelize.DATE, allowNull: true });

    // changelogs
    await queryInterface.addColumn('changelogs', 'deleted_at', { type: Sequelize.DATE, allowNull: true });
    await queryInterface.changeColumn('changelogs', 'created_at', { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') });
    await queryInterface.changeColumn('changelogs', 'updated_at', { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') });

    // downloads
    await queryInterface.addColumn('downloads', 'deleted_at', { type: Sequelize.DATE, allowNull: true });
    await queryInterface.changeColumn('downloads', 'created_at', { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') });
    await queryInterface.changeColumn('downloads', 'updated_at', { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.fn('NOW') });

    // post_polls
    await queryInterface.addColumn('post_polls', 'deleted_at', { type: Sequelize.DATE, allowNull: true });

    // post_releases
    await queryInterface.addColumn('post_releases', 'deleted_at', { type: Sequelize.DATE, allowNull: true });

    // comment_votes (tüm oylar için aynı date mixini kullanıyoruz)
    await queryInterface.addColumn('comment_votes', 'deleted_at', { type: Sequelize.DATE, allowNull: true });
    // User: eklemek isterseniz: await queryInterface.addColumn('users', 'deleted_at', { ... })
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.removeColumn('posts', 'deleted_at');
    await queryInterface.removeColumn('projects', 'deleted_at');
    await queryInterface.removeColumn('polls', 'deleted_at');
    await queryInterface.removeColumn('poll_options', 'deleted_at');
    await queryInterface.removeColumn('poll_votes', 'deleted_at');
    await queryInterface.removeColumn('releases', 'deleted_at');
    await queryInterface.removeColumn('release_files', 'deleted_at');
    await queryInterface.removeColumn('changelogs', 'deleted_at');
    await queryInterface.removeColumn('downloads', 'deleted_at');
    await queryInterface.removeColumn('post_polls', 'deleted_at');
    await queryInterface.removeColumn('post_releases', 'deleted_at');
    await queryInterface.removeColumn('comment_votes', 'deleted_at');
  }
};
